
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from ..database import db
from .dataset_utils import add_disease_to_dataset
import os

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')


@admin_bp.route('/')
@login_required
def admin_dashboard():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('Access denied: Admins only.', 'danger')
        return redirect(url_for('dashboard'))
    diseases = db.get_all_diseases()
    return render_template('admin/dashboard.html', diseases=diseases)


@admin_bp.route('/add_disease', methods=['GET', 'POST'])
@login_required
def add_disease():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('Access denied: Admins only.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        name = request.form.get('disease_name')
        description = request.form.get('description')
        symptoms = request.form.get('symptoms')
        if not name:
            flash('Disease name is required.', 'danger')
            return render_template('admin/add_disease.html')
        if not symptoms:
            flash('Symptoms are required.', 'danger')
            return render_template('admin/add_disease.html')
        success = db.add_disease(name, description)
        # Always add to dataset CSV, even if DB insert fails
        project_root = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        dataset_path = os.path.join(project_root, 'dataset', 'dataset.csv')
        add_disease_to_dataset(name, description, symptoms, dataset_path)
        if success:
            flash('Disease added successfully!', 'success')
        else:
            flash('Disease already exists in database, but symptoms were added to dataset CSV.', 'warning')
        return redirect(url_for('admin.admin_dashboard'))
    return render_template('admin/add_disease.html')

@admin_bp.route('/retrain', methods=['POST'])
@login_required
def retrain_model():
    if not hasattr(current_user, 'role') or current_user.role != 'admin':
        flash('Access denied: Admins only.', 'danger')
        return redirect(url_for('dashboard'))
    # TODO: Add logic to retrain the model
    # Example stub: call train.py
    os.system('python ../src/train.py')
    flash('Model retraining started!', 'info')
    return redirect(url_for('admin.admin_dashboard'))
