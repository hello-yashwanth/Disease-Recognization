from fpdf import FPDF
from datetime import datetime

def generate_prediction_report(report_id, date, patient_name, predicted_disease, recommended_tests):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, 'Disease Prediction Report', ln=True, align='C')
    pdf.ln(10)
    pdf.set_font('Arial', '', 12)
    pdf.cell(0, 10, f'Report ID: {report_id}', ln=True)
    pdf.cell(0, 10, f'Date: {date}', ln=True)
    pdf.cell(0, 10, f'Patient Name: {patient_name}', ln=True)
    pdf.cell(0, 10, f'Predicted Disease: {predicted_disease}', ln=True)
    pdf.ln(5)
    pdf.set_font('Arial', 'B', 12)
    pdf.cell(0, 10, 'Recommended Tests:', ln=True)
    pdf.set_font('Arial', '', 12)
    for test in recommended_tests:
        pdf.cell(0, 10, f'- {test}', ln=True)
    return pdf

def save_pdf_report(pdf, file_path):
    pdf.output(file_path)
