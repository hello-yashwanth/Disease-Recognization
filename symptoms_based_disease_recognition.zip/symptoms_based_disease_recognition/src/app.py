from flask import Flask, render_template, request, jsonify, url_for, session, redirect, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
import pandas as pd
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()
try:
    from .predict import predict_from_input
    from .database import db
    from .pdf_utils import generate_prediction_report
except Exception:
    from predict import predict_from_input
    from database import db
    from pdf_utils import generate_prediction_report
import uuid
from datetime import datetime

base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
template_dir = os.path.join(base_dir, 'templates')
static_dir = os.path.join(base_dir, 'static')
app = Flask(__name__, static_folder=static_dir, template_folder=template_dir)
app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production')


# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth'

# Register admin blueprint
from .admin.routes import admin_bp
app.register_blueprint(admin_bp)

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, user_id, username, email, role='user'):
        self.id = user_id
        self.username = username
        self.email = email
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    user = db.get_user_by_id(int(user_id))
    if user:
        return User(user['id'], user['username'], user['email'], user.get('role', 'user'))
    return None


@app.context_processor
def inject_current_year():
    from datetime import datetime
    return {'current_year': datetime.now().year}


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/auth')
def auth():
    return render_template('auth.html')


@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user=current_user)


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/api/signup', methods=['POST'])
def api_signup():
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '').strip()
    role = data.get('role', 'user').strip()

    # Validation
    if not username or not email or not password or not role:
        return jsonify({'success': False, 'message': 'All fields are required'}), 400

    if len(password) < 6:
        return jsonify({'success': False, 'message': 'Password must be at least 6 characters'}), 400

    result = db.register_user(username, email, password, role)
    return jsonify(result), 200 if result['success'] else 400


@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json() or {}
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()
    
    if not username or not password:
        return jsonify({'success': False, 'message': 'Username and password are required'}), 400
    
    result = db.login_user(username, password)
    
    if result['success']:
        user = result.get('user')
        user_obj = User(user['id'], user['username'], user['email'])
        login_user(user_obj)
        return jsonify({'success': True, 'message': 'Login successful'}), 200
    
    return jsonify(result), 401


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect('/')


@app.route('/settings')
@login_required
def settings():
    return render_template('settings.html', user=current_user)


@app.route('/predictor')
def predictor():
    # derive symptom options from dataset (Symptom_1..Symptom_N columns)
    try:
        symptoms = set()
        # from main dataset columns Symptom_*
        ds_path = os.path.join(base_dir, 'dataset', 'dataset.csv')
        if os.path.exists(ds_path):
            df = pd.read_csv(ds_path)
            symptom_cols = [c for c in df.columns if str(c).lower().startswith('symptom')]
            for c in symptom_cols:
                vals = df[c].dropna().astype(str).str.strip()
                symptoms.update([v for v in vals.unique() if v and v.lower() != 'nan'])

        # from Symptom-severity.csv (column 'Symptom')
        sev_path = os.path.join(base_dir, 'dataset', 'Symptom-severity.csv')
        if os.path.exists(sev_path):
            sdf = pd.read_csv(sev_path)
            if 'Symptom' in sdf.columns:
                symptoms.update([str(v).strip() for v in sdf['Symptom'].dropna().unique() if str(v).strip()])

        symptoms = sorted(s for s in symptoms)
    except Exception:
        symptoms = []
    return render_template('predictor.html', symptoms=symptoms)


@app.route('/api/predict', methods=['POST'])
def api_predict():
    body = request.get_json() or {}
    symptoms = body.get('symptoms', {})
    patient_name = body.get('patient_name', 'Unknown')
    if not symptoms:
        return jsonify({'error': 'No symptoms provided'}), 400
    try:
        res = predict_from_input(symptoms)
        # Save prediction to history if user is logged in
        if 'user_id' in session:
            user_id = session['user_id']
        elif hasattr(current_user, 'id'):
            user_id = current_user.id
        else:
            user_id = None
        report_id = str(uuid.uuid4())
        date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        db.save_prediction(
            user_id=user_id,
            report_id=report_id,
            patient_name=patient_name,
            predicted_disease=res.get('prediction'),
            recommended_tests=res.get('recommended_tests', [])
        )
        res['report_id'] = report_id
        res['date'] = date
        res['patient_name'] = patient_name
        return jsonify(res)
    except FileNotFoundError as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"FileNotFoundError: {error_details}")
        return jsonify({'error': f'Required file not found: {str(e)}'}), 500
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"Prediction error: {error_details}")  # Log to console for debugging
        return jsonify({'error': f'Prediction failed: {str(e)}'}), 500


# Prediction history page
@app.route('/history')
@login_required
def prediction_history():
    history = db.get_prediction_history(current_user.id)
    return render_template('history.html', history=history, user=current_user)

# Download PDF report
@app.route('/download_report/<report_id>')
@login_required
def download_report(report_id):
    record = db.get_prediction_by_report_id(report_id, current_user.id)
    if not record:
        return "Report not found", 404
    pdf = generate_prediction_report(
        report_id=record['report_id'],
        date=record['prediction_date'].strftime('%Y-%m-%d %H:%M:%S') if hasattr(record['prediction_date'], 'strftime') else str(record['prediction_date']),
        patient_name=record['patient_name'],
        predicted_disease=record['predicted_disease'],
        recommended_tests=record['recommended_tests'].split(',') if record['recommended_tests'] else []
    )
    file_path = f"/tmp/report_{report_id}.pdf"
    pdf.output(file_path)
    return send_file(file_path, as_attachment=True, download_name=f"PredictionReport_{report_id}.pdf")

@app.route('/api/debug/symptoms', methods=['GET'])
def debug_symptoms():
    """Debug endpoint to check available symptoms"""
    try:
        symptoms = set()
        ds_path = os.path.join(base_dir, 'dataset', 'dataset.csv')
        if os.path.exists(ds_path):
            df = pd.read_csv(ds_path)
            symptom_cols = [c for c in df.columns if str(c).lower().startswith('symptom')]
            for c in symptom_cols:
                vals = df[c].dropna().astype(str).str.strip()
                symptoms.update([v for v in vals.unique() if v and v.lower() != 'nan'])

        sev_path = os.path.join(base_dir, 'dataset', 'Symptom-severity.csv')
        if os.path.exists(sev_path):
            sdf = pd.read_csv(sev_path)
            if 'Symptom' in sdf.columns:
                symptoms.update([str(v).strip() for v in sdf['Symptom'].dropna().unique() if str(v).strip()])

        symptoms = sorted(s for s in symptoms)
        return jsonify({'symptoms': symptoms, 'count': len(symptoms)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 8000)), debug=True)
